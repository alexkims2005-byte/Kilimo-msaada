# Kilimo Msaada 🌱

White-and-green Flutter prototype for smallholder farmers in Taita Taveta County.

## Main screens
- Home dashboard
- Market Price Board
- Pest & Disease Identifier
- Weather Alerts

## Branding
- App name: Kilimo Msaada
- Primary colour: #168A45
- Background: white / very light green
- App icon: green agricultural sprout mark

## Build from a phone with FlutLab
1. Open https://flutlab.io/ and sign in.
2. Create a project from the uploaded ZIP/codebase.
3. Choose Android as the build target.
4. Run **Build Project**.
5. After a successful build, download the generated APK.

FlutLab supports importing a Flutter project from a ZIP file and building it in the cloud.

## Build with Codemagic
The included `codemagic.yaml` can build an APK in Codemagic after the project is connected to a repository.
