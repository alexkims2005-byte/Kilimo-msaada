import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/market_screen.dart';
import 'screens/pest_screen.dart';
import 'screens/weather_screen.dart';

const kGreen = Color(0xFF168A45);
const kDarkGreen = Color(0xFF0D6B36);
const kSoftGreen = Color(0xFFEAF7EF);

void main() => runApp(const KilimoMsaadaApp());

class KilimoMsaadaApp extends StatefulWidget {
  const KilimoMsaadaApp({super.key});
  @override
  State<KilimoMsaadaApp> createState() => _KilimoMsaadaAppState();
}

class _KilimoMsaadaAppState extends State<KilimoMsaadaApp> {
  int index = 0;
  final screens = const [HomeScreen(), MarketScreen(), PestScreen(), WeatherScreen()];

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Kilimo Msaada',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: kGreen, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF7FBF8),
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(centerTitle: false, backgroundColor: Colors.white, foregroundColor: kDarkGreen),
        cardTheme: CardTheme(color: Colors.white, elevation: 1, margin: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(18)))),
      ),
      home: Scaffold(
        body: IndexedStack(index: index, children: screens),
        bottomNavigationBar: NavigationBar(
          backgroundColor: Colors.white,
          indicatorColor: kSoftGreen,
          selectedIndex: index,
          onDestinationSelected: (i) => setState(() => index = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.storefront_outlined), selectedIcon: Icon(Icons.storefront), label: 'Market'),
            NavigationDestination(icon: Icon(Icons.health_and_safety_outlined), selectedIcon: Icon(Icons.health_and_safety), label: 'Pest ID'),
            NavigationDestination(icon: Icon(Icons.cloud_outlined), selectedIcon: Icon(Icons.cloud), label: 'Weather'),
          ],
        ),
      ),
    );
  }
}
