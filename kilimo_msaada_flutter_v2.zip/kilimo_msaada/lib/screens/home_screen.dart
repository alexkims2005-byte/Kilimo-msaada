import 'package:flutter/material.dart';
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override Widget build(BuildContext context) => SafeArea(child: ListView(padding: const EdgeInsets.all(20), children: [
    Row(children: [CircleAvatar(radius: 27, backgroundColor: Colors.green.shade100, child: Icon(Icons.agriculture, color: Colors.green.shade800, size: 30)), const SizedBox(width: 12), const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('KILIMO MSAADA', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)), Text('Msaidizi wako wa kilimo', style: TextStyle(color: Colors.black54))])]),
    const SizedBox(height: 24),
    Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: const Color(0xFF168A45), borderRadius: BorderRadius.circular(22)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('Habari, mkulima! 👋', style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)), SizedBox(height: 8), Text('Pata bei za mazao, tambua magonjwa ya mimea na angalia hali ya hewa.', style: TextStyle(color: Colors.white, height: 1.4))])),
    const SizedBox(height: 18),
    const Text('Huduma kuu', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), const SizedBox(height: 12),
    _Card(icon: Icons.storefront, title: 'Bei za Soko', text: 'Angalia na tuma bei za mazao katika Voi, Wundanyi na Mwatate.'),
    _Card(icon: Icons.camera_alt, title: 'Tambua Ugonjwa', text: 'Piga picha ya jani na upate utambuzi wa awali na ushauri.'),
    _Card(icon: Icons.cloud, title: 'Hali ya Hewa', text: 'Pata utabiri na tahadhari za mvua, ukame na hali mbaya ya hewa.'),
    const SizedBox(height: 10), const Text('Msaada wa haraka', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 8),
    Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.orange.shade50, borderRadius: BorderRadius.circular(14)), child: const Row(children: [Icon(Icons.warning_amber_rounded, color: Colors.orange), SizedBox(width: 10), Expanded(child: Text('Tahadhari: Angalia utabiri kabla ya kuvuna au kupanda.'))]))
  ]));
}
class _Card extends StatelessWidget { final IconData icon; final String title,text; const _Card({required this.icon,required this.title,required this.text}); @override Widget build(BuildContext c)=>Card(margin:const EdgeInsets.only(bottom:10), child: ListTile(contentPadding:const EdgeInsets.all(10), leading:CircleAvatar(backgroundColor:Colors.green.shade50,child:Icon(icon,color:Colors.green.shade700)), title:Text(title,style:const TextStyle(fontWeight:FontWeight.bold)), subtitle:Padding(padding:const EdgeInsets.only(top:5),child:Text(text)))); }
